export const CLEAN_CART = 'CLEAN_CART'
export const cleanCart = () => ({
    type: CLEAN_CART
})