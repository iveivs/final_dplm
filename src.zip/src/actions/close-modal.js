export const CLOSE_MODAL = 'CLOSE_MODAL'

export const closeModal = () => ( {
    type: CLOSE_MODAL,
})
