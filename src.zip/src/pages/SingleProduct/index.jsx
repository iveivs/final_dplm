import styles from './SingleProduct.module.css'
function SingleProduct() {
    return (
        <>
            <div className={styles.single}></div>
        </>
    )
}

export default SingleProduct